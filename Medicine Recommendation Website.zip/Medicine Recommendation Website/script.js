function recommendMedicine() {
    const disease = document.getElementById('disease').value;
    const result = document.getElementById('result');
    let medicine;
  
    switch (disease) {
      case 'flu':
        medicine = 'Tamiflu';
        break;
      case 'cold':
        medicine = 'Tylenol Cold & Flu';
        break;
      case 'headache':
        medicine = 'Ibuprofen';
        break;
      case 'allergy':
        medicine = 'Claritin';
        break;
      case 'body pain':
        medicine = 'Aspirin, Naproxen & Tylenol';
        break;
      case 'wheezing':
        medicine = 'Montelukast (Singulair), Zafirlukast (Accolate), & Zileuton (Zyflo)';
        break;
      case 'ear pain':
        medicine = 'Acetaminophen (Tylenol) or Ibuprofen';
        break;
      case 'leg pain':
        medicine = 'Diclofenac or Naproxen (Aleve)';
        break;
      case 'dust allergy':
        medicine = 'Fexofenadine, Loratadine & Cetirizine';
        break;
      case 'thyroid':
        medicine = 'Levothyroxine, Tirosint, Ermeza & Synthroid';
        break;
      default:
        medicine = 'Please select a disease.';
    }
  
    result.innerHTML = `<strong>Recommended Medicine:</strong> ${medicine}<br><small>Please consult a doctor for proper diagnosis and treatment.</small>`;
  }
  